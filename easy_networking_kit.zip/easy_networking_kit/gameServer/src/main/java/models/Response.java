package models;

/**
 * Created by sinemissione on 2016.06.24..
 */
public class Response {
    private int type;
    private String data;

}
