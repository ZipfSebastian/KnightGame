(function() {
    var app = angular.module('EasyNetworking');

    var MainPageCtrl = function($scope) {

    };

    app.controller('MainPageCtrl', ['$scope', MainPageCtrl]);
})();