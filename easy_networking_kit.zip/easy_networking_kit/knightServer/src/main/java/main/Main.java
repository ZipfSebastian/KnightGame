package main;

/**
 * Created by sinemissione on 2016.11.03..
 */
public class Main {

    public static void main(String[] args) {
        ServerApplication.start();
    }
}
