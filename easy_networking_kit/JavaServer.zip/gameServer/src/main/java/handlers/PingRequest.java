package handlers;

import interfaces.RequestHandler;

/**
 * Created by sinemissione on 2016.11.03..
 */
public class PingRequest extends RequestHandler {

}
