package models;

/**
 * Created by sinemissione on 2016.06.24..
 */
public class Response {
    private String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
