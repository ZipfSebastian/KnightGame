package responses;

import models.Response;

/**
 * Created by sinemissione on 2016.11.05..
 */
public class InitResponse extends Response {

    private boolean success;
}
