package models;

/**
 * Created by sinemissione on 2016.11.05..
 */
public class Enemy {

    private int id;
    private Vector2 position;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Vector2 getPosition() {
        return position;
    }

    public void setPosition(Vector2 position) {
        this.position = position;
    }
}
