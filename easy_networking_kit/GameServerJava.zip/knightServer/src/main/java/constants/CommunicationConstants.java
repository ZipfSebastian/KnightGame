package constants;

/**
 * Created by sinemissione on 2016.11.04..
 */
public class CommunicationConstants {

    public static final String SEARCH_RESPONSE = "SearchResponse";
    public static final String LOAD_GAME_RESPONSE = "LoadGameResponse";
    public static final String START_GAME_RESPONSE = "StartGameResponse";
    public static final String INIT_RESPONSE = "InitResponse";
    public static final String POSITION_RESPONSE = "PositionResponse";
    public static final String GAME_END_RESPONSE = "GameEndResponse";
}
