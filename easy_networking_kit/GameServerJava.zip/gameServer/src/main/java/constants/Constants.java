package constants;

/**
 * Created by zipfs on 2016. 01. 16..
 */
public class Constants {

    public static final int TEAM_OFFSET = 7;
    public static final int UDP = 0;
    public static final int TCP = 1;

    public static final String BAD_REQUEST = "BAD_REQUEST";
}
